#!/bin/sh

java -Xms256M -Xmx512M -jar ./lib/studio.jar ./config/studio.cfg

$