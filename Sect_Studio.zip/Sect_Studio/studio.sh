#!/bin/zsh

cd /usr/local/Sect_Studio
java -Xms256M -Xmx512M -jar lib/studio.jar config/studio.cfg

$