#!/bin/zsh

cd /usr/local/Sect_Studio
sudo java -jar simulator2.jar

$