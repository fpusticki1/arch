#! /bin/sh


sudo cp -f /usr/local/OpenVPN/resolv_VPN.conf /run/systemd/resolve/resolv.conf
